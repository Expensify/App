import type { QueryResult, QueryResultRow, SQLiteQueryParams } from '../types';
import type { NitroSQLiteQueryResult } from '../specs/NitroSQLiteQueryResult.nitro';
export declare function execute<Row extends QueryResultRow = never>(dbName: string, query: string, params?: SQLiteQueryParams): QueryResult<Row>;
export declare function executeManaged<Row extends QueryResultRow = never>(dbName: string, query: string, params?: SQLiteQueryParams): QueryResult<Row>;
export declare function executeNative<Row extends QueryResultRow = never>(dbName: string, query: string, params?: SQLiteQueryParams): QueryResult<Row>;
export declare function executeAsync<Row extends QueryResultRow = never>(dbName: string, query: string, params?: SQLiteQueryParams): Promise<QueryResult<Row>>;
export declare function executeAsyncManaged<Row extends QueryResultRow = never>(dbName: string, query: string, params?: SQLiteQueryParams): Promise<QueryResult<Row>>;
export declare function executeAsyncNative<Row extends QueryResultRow = never>(dbName: string, query: string, params?: SQLiteQueryParams): Promise<QueryResult<Row>>;
export declare function buildJSQueryResult<Row extends QueryResultRow = never>(result: NitroSQLiteQueryResult): QueryResult<Row>;
//# sourceMappingURL=execute.d.ts.map
export interface QueuedOperation {
    /**
     * Starts the operation
     */
    start: () => void;
}
export type DatabaseQueue = {
    queue: QueuedOperation[];
    inProgress: boolean;
};
export declare function openDatabaseQueue(dbName: string): void;
export declare function closeDatabaseQueue(dbName: string): void;
export declare function isDatabaseOpen(dbName: string): boolean;
export declare function throwIfDatabaseIsNotOpen(dbName: string): void;
export declare function getDatabaseQueue(dbName: string): DatabaseQueue;
export declare function queueOperationAsync<Result>(dbName: string, callback: () => Promise<Result>): Promise<Result>;
export declare function startOperationSync<Result>(dbName: string, callback: () => Result): Result;
//# sourceMappingURL=DatabaseQueue.d.ts.map